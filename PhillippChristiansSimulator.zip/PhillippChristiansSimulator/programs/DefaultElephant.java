public class DefaultElephant extends Elefant { public void main() { 
turnleft();
}}