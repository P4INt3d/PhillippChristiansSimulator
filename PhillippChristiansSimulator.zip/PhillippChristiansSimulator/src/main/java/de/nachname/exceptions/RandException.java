package de.nachname.exceptions;

public class RandException extends RuntimeException{

    public RandException(){
        super("Hier ist der Rand");
    }
}
