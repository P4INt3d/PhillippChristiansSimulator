package de.nachname.exceptions;

public class TileException extends RuntimeException{

    public TileException(String msg){
        super("msg");
    }
}
