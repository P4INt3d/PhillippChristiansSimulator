package de.nachname;

import javafx.application.Application;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.KeyCombination;
import javafx.scene.layout.Pane;
import javafx.scene.layout.Priority;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import java.util.Arrays;

public class Main extends Application {

    // VM Args: --module-path "\path\to\javafx-sdk-19\lib" --add-modules javafx.controls,javafx.fxml
    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage primaryStage) {
        Territorium territorium = new Territorium();
        MainStage stage = new MainStage(territorium);
        stage.show();

    }

    public void test(){
        Territorium t = new Territorium(9, 6);
        Elefant e = t.getActor();
        t.setMouse(3,5);
        t.setP(5,1,4);
        t.setP(1,2,3);
        System.out.println(Arrays.deepToString(t.getGrid()).replace("], ", "]\n"));
        System.out.println();

        try {
            e.step();
            e.step();
            e.step();
            e.turn();
            e.step();
            e.step();
        } catch (Exception exc){
            System.out.println(exc);
        }
        System.out.println();
        System.out.println(Arrays.deepToString(t.getGrid()).replace("], ", "]\n"));

    }
}