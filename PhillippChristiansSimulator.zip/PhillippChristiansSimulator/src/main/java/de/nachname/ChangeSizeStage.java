package de.nachname;

import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.Spinner;
import javafx.scene.control.TextField;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class ChangeSizeStage extends Stage {
    private Label messagelabel;

    public ChangeSizeStage(MainStage st){
        setTitle("Change Size");
        Spinner<Integer> rowSpinner = new Spinner<>(4, 20, 5);
        Spinner<Integer> colSpinner = new Spinner<>(4, 20, 8);
        TextField a = new TextField();
        a.setPromptText("Rows:");
        TextField b = new TextField();
        b.setPromptText("Columns:");
        Button save = new Button("Save");
        save.setOnAction(e -> {
            Territorium territoriumNew = new Territorium(rowSpinner.getValue(), colSpinner.getValue());
            MainStage stage = new MainStage(territoriumNew);
            stage.show();
            this.close();
            st.close();
        });
        Button cancel = new Button("Cancel");
        cancel.setOnAction(e -> this.close());
        VBox vbox = new VBox();
        vbox.getChildren().addAll(rowSpinner,colSpinner, save, cancel);
        Scene sc = new Scene(vbox, 400, 250);
        this.setScene(sc);
    }
}
