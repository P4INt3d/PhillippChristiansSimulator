package de.christians;

public class MainWithoutVMArgs {
    public static void main(String[] args) {
        Main.main(args);
    }

}