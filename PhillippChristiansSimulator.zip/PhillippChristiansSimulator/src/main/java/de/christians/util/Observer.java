package de.christians.util;

public interface Observer {
    public abstract void update();
}
