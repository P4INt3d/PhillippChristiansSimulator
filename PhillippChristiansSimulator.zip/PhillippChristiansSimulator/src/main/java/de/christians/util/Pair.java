package de.christians.util;

public record Pair<T>(T value1, T value2) {

}
