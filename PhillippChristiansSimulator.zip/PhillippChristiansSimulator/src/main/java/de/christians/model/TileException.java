package de.christians.model;

public class TileException extends RuntimeException{

    public TileException(String msg){
        super("msg");
    }
}
